def f(): 
    print(s) 
s = "I love Paris in the summer!"
f()


def f(): 
    s = "I love London!"
    print(s) 

s = "I love Paris!" 
f()
print(s)

'''
def f():
    print(s)
    s = "I love London!"
    print(s)

s = "I love Paris!"
f()
'''

def f():
    global s
    print(s)
    s = "Only in spring, but London is great as well!"
    print(s)
s = "I am looking for a course in Paris!" 
f()
print(s)



def f():
    s = "I am globally not known"
    print(s) 

f()
print(s)


