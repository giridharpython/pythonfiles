# variablelength
def display(*info):  #-----> tuple
    print(info)
display(10,20,30,40)

def displayoutput(**book):  #--> dictionary
    for key in book:
        print(key)
        print(book[key])
# passing dictionary items
displayoutput(chap1 = 10 , chap2 = 20 )
